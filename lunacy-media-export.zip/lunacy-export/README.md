# Lunacy Media - Project Export

This export contains your complete Lunacy Media website project.

## Contents

### 📁 `/html/public`
**Built HTML files ready to deploy**
- Complete production-ready HTML, CSS, and JavaScript
- Includes all assets and optimized bundles
- Can be deployed directly to any static hosting (Netlify, Vercel, GitHub Pages, etc.)
- To use: Upload the contents of this folder to your hosting provider

### 📁 `/built-files`
**Production build artifacts**
- `index.html` - Main HTML file with all SEO meta tags
- `/assets` - Optimized CSS and JavaScript bundles
- Ready for deployment to static hosting

### 📁 `/source-code`
**Complete source code for development**
- Full React/TypeScript source code
- tRPC server code
- Database schema and migrations
- Configuration files (Vite, TypeScript, Vitest)
- Package dependencies list

## How to Use

### Option 1: Deploy Built Files (Fastest)
1. Use the files in `/html/public` or `/built-files`
2. Upload to your hosting provider (Netlify, Vercel, etc.)
3. Point your domain to the hosting provider
4. Done! Your site is live

### Option 2: Continue Development
1. Extract `/source-code` to your local machine
2. Run `pnpm install` to install dependencies
3. Run `pnpm dev` to start development server
4. Make changes as needed
5. Run `pnpm build` to create production build

## Key Features Included

✓ NASA moon texture via tRPC server proxy
✓ Keyboard navigation (arrow keys for orbital sections)
✓ Ambient audio with crossfade transitions
✓ SEO optimized (meta tags, keywords, H1 heading)
✓ Responsive design
✓ Authentication ready
✓ Newsletter subscription
✓ Analytics tracking

## Environment Variables Needed (for development)

If you want to continue development, you'll need:
- `DATABASE_URL` - Database connection string
- `JWT_SECRET` - Session signing secret
- `VITE_APP_ID` - OAuth app ID
- `OAUTH_SERVER_URL` - OAuth server URL
- Other Manus API credentials

## Deployment Options

### Static Hosting (Recommended for built files)
- Netlify, Vercel, GitHub Pages, Cloudflare Pages
- Upload `/html/public` contents

### Full Stack Hosting (For development)
- Manus (current), Railway, Render, Fly.io
- Deploy the entire `/source-code` folder

## Support

For questions about the code structure, refer to the template documentation in `/source-code`.

---

**Project**: Lunacy Media — Your Forever Endeavour
**Last Updated**: March 4, 2026
